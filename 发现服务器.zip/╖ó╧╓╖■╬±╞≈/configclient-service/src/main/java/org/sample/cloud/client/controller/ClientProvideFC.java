package org.sample.cloud.client.controller;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("client") // 注意,这里的值对应的是provide的applicatoin.name
public interface ClientProvideFC {
    @RequestMapping(method = RequestMethod.GET, value = "/index")
    String index(@RequestParam("str") String str);
}
